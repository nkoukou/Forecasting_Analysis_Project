This zip includes 4 folders and 5 files:

- "test1_graphs", contains graphs of department profiles for division "ACTION CONCEPTS" of test 1
- "test2_graphs", contains graphs of product level forecasts and residuals for all product variants of test 2
- "test3_graphs", contains graphs of division level and variant level forecasts for all product variants of test 3
  The last two folders contain 3 and 4 graphs respectively which illustrate the actual sales of the seven variants given in sales_data.xlsx, sheet="FullData"
- "report", contains all relevant tex documents for the final project report as well as a pdf version of the report (plots are directly taken from all three folders above)

- "sales_data.xlsx", contains the initial dataset used to analyse data and perform the tests
- "sales_data_final.xlsx", contains the initial dataset and incorporates all the results in blue background colour for all three tests
- 3 R scripts, one for each test.
### Performs test2 (borrowing scripts from plots.R and predictors.R).
### Search for "C:\" to change directories in the script.

if(!exists("divisions", mode="function")) source('test1v2.R')
require(xlsx)

SalesData3 = read_excel("C:\\Users\\Nikos\\Desktop\\itim\\sales_data.xlsx", sheet=4)

actual_dragon = ts(c(171,	93,	37,	67,	51,	94,	121,	179,	168,	163,
                     213,	247,	219,	149,	156,	176,	212), start=2015+35/52, frequency=52)
actual_minecraft = ts(c(40,	45,	34,	94,	49,	66,	82,	111,	100,	170,
                        221,	277,	105,	23,	8,	11,	13), start=2015+35/52, frequency=52)
actual_starwars = ts(c(188,	183,	203,	240,	269,	305,	264,	532,
                       616,	670, 895,	981,	406,	331,	267,	243,	236), start=2015+35/52, frequency=52)
actual_tech = ts(c(91,	138,	140,	243,	171,	244,	309,	374,
                       365,	421,	529,	621,	325,	122,	112,	141,	168), start=2015+35/52, frequency=52)

rows3 = nrow(SalesData3)
cols3 = ncol(SalesData3)
dummy_rows3 = c(-1,-2)
dummy_cols3 = c(-1:-5,-93,-94)

select_class = function(row3){
  current_data = as.integer(data.matrix(SalesData3[row3, dummy_cols3]))
}

ts_class = function(row3){
  current_data = select_class(row3)
  ts_data = ts(current_data, start=2014, frequency=52)
}

multireg_div = function(row3){
  data = create_timeseries_div(SalesData3[row3,1])[1:87]
  data = ts(data, start=2014, frequency=52)
  fit = tslm(data ~ trend + season)
  sum_up = summary(fit)
  fitted_data = fitted(fit)
  
  fcasts = forecast(fit,h=17)
  fcast=c();i=1
  for (point in fcasts$mean){
    fcast[i] = fcasts$mean[i]
    i=i+1
  }
  fcast = ts(fcast, start=2015+35/52, frequency=52)
  
  return_list = list("sum_up"=sum_up, "fitted_data"=fitted_data, "forecast"=fcast)
  return(return_list)
}

forecast_class = function(row3, cout=FALSE){
  
  data_divf = multireg_div(row3)$forecast
  avg_divf = mean(data_divf); std_divf = sd(data_divf)
  norm_data_divf = (data_divf - avg_divf)/std_divf
  
  data_pre = ts_class(row3)
  data_class = data_pre
  fit_class = tslm(data_class ~ trend + season)
  fitted_class = fitted(fit_class)
  fcast_class = forecast(fit_class, level=c(1), h=17)
  
  avg_class = mean(data_class); std_class = sd(data_class)
  data_class_append = norm_data_divf*std_class + avg_class
  data_class = as.double(data_class_append)
  data_class = ts(data_class, start=2015+35/52, frequency=52)
  
  if (cout==FALSE){
    plot(fcast_class, main=SalesData3[row3,4], xlab='Year (weeks)', ylab='Total Sales')
    lines(data_class, col=2)
    lines(data_pre, col=3)
    abline(v=2015+35/52, col=1)
    legend("topleft", lty=1, col=c("blue",2,3), legend = c("Variant level", "Division level","Actual Sales"))
  }
  else{
    png(filename=paste(gsub("\\.","_", SalesData3[row3,4]), "_forecast.png",sep=""))
    plot(fcast_class, main=SalesData3[row3,4], xlab='Year (weeks)', ylab='Total Sales')
    lines(data_class, col=2)
    lines(data_pre, col=3)
    abline(v=2015+35/52, col=1)
    legend("topleft", lty=1, col=c("blue",2,3), legend = c("Variant level", "Division level","Actual Sales"))
    dev.off()
  }
  return(list("div"=as.double(data_class_append), "var"=as.double(fcast_class$mean)))
}

forecast_class_all = function(cout=FALSE){
  if (cout==FALSE){
    for (row3 in seq(3, rows3)){
      forecast_class(row3, cout=FALSE)
    }
  }
  else{
    fcast_data_set = SalesData3
    
    for (col3 in seq(1,17)){
      fcast_data_set[1,cols3+col3] = 2015
      fcast_data_set[2,cols3+col3] = fcast_data_set[2,40+col3]
    }
    setwd('C:\\Users\\Nikos\\Desktop\\itim\\test3_graphs')
    for (row3 in seq(3, rows3)){
      current_data = forecast_class(row3, cout=TRUE)
      for (col3 in seq(1,17)){
        fcast_data_set[row3,cols3+col3] = current_data$div[col3] 
        fcast_data_set[rows3+row3-2,cols3+col3] = current_data$var[col3] 
      }
      write.xlsx(fcast_data_set, "fitted_data_set2.xlsx", sheetName="fitted_data")
    }
    setwd('C:\\Users\\Nikos\\Desktop\\itim')
  }
  
}









